(function(){
  // Rebase internal xrefs rendered from header-links.adoc to that source page.
  // Otherwise a relative xref works on header-links.html but breaks when the
  // same list is embedded in another component/module/deep article.
  document.querySelectorAll('.header-adoc-nav[data-header-source-url]').forEach(function(nav){
    var originalPage;
    try { originalPage = new URL(nav.getAttribute('data-header-source-url'), document.baseURI); }
    catch(e) { return; }
    nav.querySelectorAll('a[href]').forEach(function(anchor){
      var href = anchor.getAttribute('href');
      if (!href || href.startsWith('#') || href.startsWith('/') || /^[a-z][a-z\d+.-]*:/i.test(href) || href.startsWith('//')) return;
      try { anchor.href = new URL(href, originalPage).href; } catch(e) {}
      if (anchor.target === '_blank') anchor.rel = 'noopener noreferrer';
    });
  });

  var toggle=document.querySelector('.mobile-nav-toggle');
  var sidebar=document.querySelector('.docs-sidebar');
  var header=document.querySelector('.docs-header');
  // v9: "phone layout" = narrow screens, or touch phones held sideways (short screen).
  // Keep this query identical to the one in css/site.css. Laptops never match it.
  var phoneMQ=window.matchMedia('(max-width: 750px), (hover: none) and (pointer: coarse) and (max-height: 500px)');

  // Phone layout hides the header links, so copy them (already rebased above) into the top of the drawer.
  // The copy is display:none outside the phone layout.
  var headerLinks=document.querySelector('.docs-header .docs-toplinks');
  var sidebarInner=sidebar&&sidebar.querySelector('.sidebar-inner');
  if(headerLinks&&sidebarInner&&headerLinks.querySelector('a[href]')){
    var drawerLinks=document.createElement('nav');
    drawerLinks.className='drawer-links';
    drawerLinks.setAttribute('aria-label','Contact and profiles');
    var linkList=document.createElement('ul');
    headerLinks.querySelectorAll('a[href]').forEach(function(a){
      var li=document.createElement('li'); var copy=a.cloneNode(true);
      copy.removeAttribute('class'); li.appendChild(copy); linkList.appendChild(li);
    });
    drawerLinks.appendChild(linkList);
    sidebarInner.insertBefore(drawerLinks,sidebarInner.firstChild);
  }

  // Slide-in navigation drawer (phone layout only; the button is hidden elsewhere).
  // Opens just below the header wherever the reader is, locks page scroll, and closes on
  // backdrop tap, Escape, choosing a page, or leaving the phone layout.
  if(toggle&&sidebar){
    var backdrop=document.createElement('div');
    backdrop.className='nav-backdrop';
    backdrop.setAttribute('aria-hidden','true');
    document.body.appendChild(backdrop);
    var openLabel=toggle.textContent, closeLabel='✕ Close';
    var isOpen=function(){return sidebar.classList.contains('open');};
    var placeDrawer=function(){
      var bottom=header?Math.max(0,Math.round(header.getBoundingClientRect().bottom)):0;
      document.documentElement.style.setProperty('--drawer-top',bottom+'px');
    };
    var setDrawer=function(open,restoreFocus){
      if(open)placeDrawer();
      sidebar.classList.toggle('open',open);
      backdrop.classList.toggle('is-visible',open);
      document.documentElement.classList.toggle('nav-open',open);
      toggle.setAttribute('aria-expanded',String(open));
      toggle.textContent=open?closeLabel:openLabel;
      if(open){sidebar.setAttribute('tabindex','-1');sidebar.focus({preventScroll:true});}
      else if(restoreFocus){toggle.focus({preventScroll:true});}
    };
    toggle.addEventListener('click',function(){setDrawer(!isOpen(),false);});
    backdrop.addEventListener('click',function(){setDrawer(false,true);});
    document.addEventListener('keydown',function(e){if((e.key==='Escape'||e.key==='Esc')&&isOpen())setDrawer(false,true);});
    sidebar.addEventListener('click',function(e){if(isOpen()&&e.target.closest('a[href]'))setDrawer(false,false);});
    var leavePhoneLayout=function(){if(!phoneMQ.matches&&isOpen())setDrawer(false,false);};
    if(phoneMQ.addEventListener)phoneMQ.addEventListener('change',leavePhoneLayout);
    else if(phoneMQ.addListener)phoneMQ.addListener(leavePhoneLayout);
    window.addEventListener('resize',function(){if(isOpen())placeDrawer();});
  }

  // Phone layout: diagrams shrink to the screen width, so let readers open them at full size.
  if(phoneMQ.matches){
    document.querySelectorAll('.article-body .imageblock img').forEach(function(img){
      if(img.closest('a'))return;
      var wrap=function(){
        if(!img.naturalWidth||img.naturalWidth<=img.getBoundingClientRect().width*1.15)return;
        var link=document.createElement('a');
        link.href=img.currentSrc||img.src; link.target='_blank'; link.rel='noopener'; link.className='img-zoom';
        link.title='Open full-size image';
        img.parentNode.insertBefore(link,img); link.appendChild(img);
        var hint=document.createElement('span');
        hint.className='img-zoom-hint'; hint.setAttribute('aria-hidden','true'); hint.textContent='Tap to view full size';
        link.appendChild(hint);
      };
      if(img.complete)wrap(); else img.addEventListener('load',wrap,{once:true});
    });
  }

  // Antora may emit a blank navigation-group heading for malformed or unlabeled
  // parent nodes. Do not leave an arrow-only toggle in the sidebar.
  // Also normalize text in headings that contain nested inline markup.
  document.querySelectorAll('.nav-group > .nav-toggle').forEach(function(button){
    var label = button.querySelector('.nav-label');
    if (!label) return;
    var text = (label.textContent || '').replace(/\s+/g, ' ').trim();
    if (!text) {
      var descendants = button.parentElement.querySelectorAll('.nav-children .nav-row a, .nav-children .nav-toggle .nav-label');
      for (var i=0; i<descendants.length; i++) {
        var candidate=(descendants[i].textContent || '').replace(/\s+/g, ' ').trim();
        if (candidate) { text=candidate; break; }
      }
      if (!text) text='Untitled section';
      button.dataset.fallbackLabel='true';
    }
    label.textContent=text;
  });

  // UI display normalization for manually authored navigation:
  // * Topic and first child both named "Data Structure" => rename child "Overview".
  // * If that child has nested subtopics, promote them one indentation level.
  // This preserves the overview URL, avoids duplicate visible titles, and leaves
  // nav.adoc untouched. It only applies to exact duplicate first-child labels.
  document.querySelectorAll('.docs-sidebar .nav-group:not(.nav-linked-group)').forEach(function(group){
    var toggle = group.querySelector(':scope > .nav-toggle');
    var childList = group.querySelector(':scope > .nav-children > ul.nav-tree');
    if (!toggle || !childList) return;
    var label = toggle.querySelector('.nav-label');
    var first = childList.querySelector(':scope > li.nav-item:first-child');
    if (!label || !first) return;
    var link = first.querySelector(':scope > .nav-row > a, :scope > .nav-linked-group > .nav-linked-row > a');
    if (!link) return;
    function title(x){return (x.textContent||'').replace(/\s+/g,' ').trim().toLocaleLowerCase();}
    if (!title(label) || title(label)!==title(link)) return;
    link.textContent = 'Overview';
    link.setAttribute('title', 'Open ' + label.textContent.trim() + ' overview');
    var subitems = first.querySelector(':scope > ul.nav-tree, :scope > .nav-linked-group > .nav-children > ul.nav-tree');
    if (!subitems) return;
    var rest = first.nextSibling;
    Array.prototype.slice.call(subitems.children).forEach(function(item){childList.insertBefore(item,rest);});
    // The overview child no longer needs its own empty dropdown.
    if (first.querySelector(':scope > .nav-linked-group')) {
      var oldGroup=first.querySelector(':scope > .nav-linked-group');
      var row=oldGroup.querySelector(':scope > .nav-linked-row');
      if (row) {
        var oldButton=row.querySelector('button.nav-toggle');
        if (oldButton) oldButton.remove();
        first.insertBefore(row,oldGroup);
      }
      oldGroup.remove();
    } else {
      subitems.remove();
    }
  });

  // Highlight the active Antora article before initializing expandable groups.
  var here=window.location.pathname;
  document.querySelectorAll('.docs-sidebar a').forEach(function(a){
    try{if(new URL(a.href).pathname===here){a.classList.add('is-current');a.setAttribute('aria-current','page');}}
    catch(e){}
  });

  // Avoid native <details>/<summary> rendering: labels always remain visible.
  // A semantic button handles keyboard interaction and announced expanded state.
  function getGroupToggle(group){
    return group.querySelector(':scope > .nav-toggle, :scope > .nav-linked-row > .nav-toggle');
  }
  function setGroupOpen(group,open){
    var button=getGroupToggle(group);
    if(!button)return;
    group.classList.toggle('is-collapsed',!open);
    button.setAttribute('aria-expanded',String(open));
    var chevron=button.querySelector('.nav-chevron');
    if(chevron)chevron.textContent=open?'▾':'▸';
  }
  document.querySelectorAll('.nav-group').forEach(function(group,i){
    var button=getGroupToggle(group);
    var children=group.querySelector(':scope > .nav-children');
    if(!button||!children)return;
    if(!children.id)children.id='nav-children-'+(i+1);
    button.setAttribute('aria-controls',children.id);
    // Keep the group containing the current article expanded; collapse others.
    setGroupOpen(group,!!group.querySelector('a[aria-current="page"]'));
  });
  document.addEventListener('click',function(event){
    var button=event.target.closest('.nav-toggle');
    if(!button)return;
    var group=button.closest('.nav-group');
    if(group)setGroupOpen(group,button.getAttribute('aria-expanded')!=='true');
  });

  var filter=document.getElementById('nav-filter');
  if(filter&&sidebar){
    filter.addEventListener('input',function(){
      var q=filter.value.toLowerCase().trim();
      var entries=Array.prototype.slice.call(sidebar.querySelectorAll('li.nav-item'));
      entries.reverse().forEach(function(li){
        var row=li.querySelector(':scope > .nav-row, :scope > .nav-group > .nav-row');
        var label=row?row.textContent.toLowerCase():'';
        var children=li.querySelectorAll('li.nav-item');
        var childMatch=Array.prototype.some.call(children,function(child){return !child.hidden;});
        li.hidden=!!q&&!label.includes(q)&&!childMatch;
        var group=li.querySelector(':scope > .nav-group');
        if(q&&group&&(childMatch||label.includes(q)))setGroupOpen(group,true);
      });
    });
  }
  var toc=document.getElementById('js-local-toc');
  var article=document.querySelector('.article-body');
  if(toc&&article){article.querySelectorAll('h2[id], h3[id]').forEach(function(h){var a=document.createElement('a');a.href='#'+encodeURIComponent(h.id);a.textContent=h.textContent;a.className=h.tagName==='H3'?'level3':'level2';toc.appendChild(a);});}
})();
